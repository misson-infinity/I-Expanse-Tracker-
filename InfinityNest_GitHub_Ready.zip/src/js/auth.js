// Auth logic
